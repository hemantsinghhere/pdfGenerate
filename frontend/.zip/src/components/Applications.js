import React from 'react'

const Applications = () => {
  return (
    <div>
      Application
    </div>
  )
}

export default Applications
