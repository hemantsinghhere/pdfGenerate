
import './App.css';
import Buttons from './components/Buttons';
import Forms from './components/Forms';

function App() {
  return (
    <>
    <Forms />
    <Buttons />
    </>
  );
}

export default App;
