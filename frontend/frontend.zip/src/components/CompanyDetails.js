import React from 'react'

const CompanyDetails = () => {
  return (
    <div>
      <h1>company details</h1>
    </div>
  )
}

export default CompanyDetails
