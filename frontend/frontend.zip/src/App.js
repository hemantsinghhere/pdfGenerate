
import './App.css';
import Buttons from './components/Buttons';
// import Forms from './components/Forms';
import Applications from './components/Applications'
// import UpdateBug from './components/UpdateBug';

function App() {
  return (
    <>
    <Applications />
    {/* <Forms /> */}
    <Buttons />
    {/* <UpdateBug/> */}
    </>
  );
}

export default App;
