
import './App.css';
import Buttons from './components/Buttons';
import Applications from './components/Applications';

function App() {
  return (
    <>
    <Applications />
    <Buttons />
    </>
  );
}

export default App;
